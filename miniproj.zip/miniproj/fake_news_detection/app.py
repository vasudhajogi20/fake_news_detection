from flask import Flask, request, jsonify
import joblib
from sklearn.feature_extraction.text import TfidfVectorizer
import re
import string

# Initialize Flask app
app = Flask(__name__)

# Load the saved model and vectorizer
model = joblib.load('fake_news_model(2).pkl')
vectorizer = joblib.load('vectorizer.pkl')  # You need to save and load the vectorizer too

# Preprocessing function for incoming text
def wordopt(text):
    text = text.lower()
    text = re.sub(r'\[.*?\]', '', text)  # Use raw string literals
    text = re.sub(r'\\W', ' ', text)
    text = re.sub(r'https?://\S+|www\.\S+', '', text)
    text = re.sub(r'<.*?>+', '', text)
    text = re.sub(r'[%s]' % re.escape(string.punctuation), '', text)
    text = re.sub(r'\w*\d\w*', '', text)
    return text


# Define prediction endpoint
@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    text = data.get('text', '')

    # Preprocess the text
    text = wordopt(text)

    # Vectorize the text
    text_vectorized = vectorizer.transform([text])

    # Predict using the model
    prediction = model.predict(text_vectorized)

    result = "Real News" if prediction == 1 else "Fake News"

    return jsonify({'prediction': result})

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
